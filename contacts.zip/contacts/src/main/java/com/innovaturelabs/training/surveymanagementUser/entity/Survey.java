package com.innovaturelabs.training.surveymanagementUser.entity;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Survey {
	
	 public static enum Status {
	        INACTIVE((byte) 0),
	        ACTIVE((byte) 1);

	        public final byte value;

	        private Status(byte value) {
	            this.value = value;
	        }
	    }
	public static Object StartDate;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer surveyId;
	private String surveyName;
	private String description;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Admin admin;
    private byte status;
    
    
    
    public Survey(Integer surveyId) {
        this.surveyId = surveyId;
    }
    
    public byte getStatus() {
		return status;
	}
	public void setStatus(byte status) {
		this.status = status;
	}
	@Temporal(TemporalType.DATE)
    private Date startDate;
    @Temporal(TemporalType.DATE)
    private Date endDate;
	public Integer getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(Integer surveyId) {
		this.surveyId = surveyId;
	}
	public String getSurveyName() {
		return surveyName;
	}
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Admin getAdmin() {
		return admin;
	}
	
	public Survey() {
		super();
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
    

}
