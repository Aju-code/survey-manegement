package com.innovaturelabs.training.surveymanagementUser.repository;

import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementUser.entity.Answer;

public interface AnswerRepository extends Repository<Answer, Integer>{
	
	Answer save(Answer answer);

}
