package com.innovaturelabs.training.surveymanagementUser.repository;

import java.util.Collection;
import java.util.Date;

import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementUser.entity.Survey;


public interface SurveyRepository extends Repository<Survey, Integer>{
	
	
	Collection<Survey> findByStatus(byte status);
	
}
