package com.innovaturelabs.training.surveymanagementUser.service;

import java.util.Collection;

import com.innovaturelabs.training.surveymanagementUser.entity.Country;

public interface CountryService {
	
	 Collection<Country> listCountry();

}
