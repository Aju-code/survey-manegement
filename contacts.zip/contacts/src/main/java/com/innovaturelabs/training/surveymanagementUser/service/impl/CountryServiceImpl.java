package com.innovaturelabs.training.surveymanagementUser.service.impl;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovaturelabs.training.surveymanagementUser.entity.Country;
import com.innovaturelabs.training.surveymanagementUser.repository.CountryRepository;
import com.innovaturelabs.training.surveymanagementUser.service.CountryService;

@Service
public class CountryServiceImpl implements CountryService{
	
	 @Autowired 
	    private CountryRepository countryRepository;
	
	public Collection<Country> listCountry(){
    	return countryRepository.findAll();
    }

}
