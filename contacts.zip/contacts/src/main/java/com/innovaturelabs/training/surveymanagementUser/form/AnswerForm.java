package com.innovaturelabs.training.surveymanagementUser.form;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class AnswerForm {
	@Size(max=225)
    @NotBlank
    private String answer;

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

}
