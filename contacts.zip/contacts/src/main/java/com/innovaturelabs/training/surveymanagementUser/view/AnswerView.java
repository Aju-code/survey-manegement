package com.innovaturelabs.training.surveymanagementUser.view;

import com.innovaturelabs.training.surveymanagementUser.entity.Answer;

public class AnswerView {
	
	private final int answerId;
    private final int survey;
    private final int user;
    private final int question;
    private final String answer;
    
    public AnswerView(Answer answer) {
        this.answerId=answer.getAnswerId();
        this.survey=answer.getSurvey().getSurveyId();
        this.user=answer.getUser().getUserId();
        this.question=answer.getQuestion().getQuestionId();
        this.answer=answer.getAnswer();
    }

    public int getAnswerId() {
        return answerId;
    }

    public int getSurvey() {
        return survey;
    }

    public int getUser() {
        return user;
    }

    public String getAnswer() {
        return answer;
    }

    public int getQuestion() {
        return question;
    }

}
