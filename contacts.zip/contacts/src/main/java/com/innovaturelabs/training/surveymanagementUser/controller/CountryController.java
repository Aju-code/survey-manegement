package com.innovaturelabs.training.surveymanagementUser.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovaturelabs.training.surveymanagementUser.entity.Country;
import com.innovaturelabs.training.surveymanagementUser.service.CountryService;

@RestController
@RequestMapping("/country")
public class CountryController {

	 @Autowired
	    private CountryService countryService;

	
	 @GetMapping
	    public Collection<Country> listCountry(){
	    	return countryService.listCountry();
	    }
	
}
