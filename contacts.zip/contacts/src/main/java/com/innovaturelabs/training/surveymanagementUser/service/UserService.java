/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementUser.service;

import java.util.Collection;

import org.springframework.validation.Errors;

import com.innovaturelabs.training.surveymanagementUser.entity.Question;
import com.innovaturelabs.training.surveymanagementUser.entity.Survey;
import com.innovaturelabs.training.surveymanagementUser.entity.User;
import com.innovaturelabs.training.surveymanagementUser.exception.BadRequestException;
import com.innovaturelabs.training.surveymanagementUser.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementUser.form.AnswerForm;
import com.innovaturelabs.training.surveymanagementUser.form.ChangePassword;
import com.innovaturelabs.training.surveymanagementUser.form.LoginForm;
import com.innovaturelabs.training.surveymanagementUser.form.UserForm;
import com.innovaturelabs.training.surveymanagementUser.view.AnswerView;
import com.innovaturelabs.training.surveymanagementUser.view.LoginView;
import com.innovaturelabs.training.surveymanagementUser.view.UserView;

/**
 *
 * @author nirmal
 */
public interface UserService {

    UserView add(UserForm form);

    UserView currentUser();

    LoginView login(LoginForm form, Errors errors) throws BadRequestException;

    LoginView refresh(String refreshToken) throws BadRequestException;

    Collection<User> list();
    
    Collection<Survey> lists();
    
    Collection<Question> attendSurvey(Integer surveyId);
    
    UserView get(Integer userId) throws NotFoundException;
    
    AnswerView add(Integer surveyId,Integer questionId,AnswerForm form);

	UserView updatePassword(ChangePassword form);

//	UserView changePassword(Integer userId) throws NotFoundException;
}
