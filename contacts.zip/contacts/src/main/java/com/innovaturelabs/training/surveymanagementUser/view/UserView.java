/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementUser.view;

import com.innovaturelabs.training.surveymanagementUser.entity.User;
import com.innovaturelabs.training.surveymanagementUser.json.Json;

import java.util.Date;

/**
 *
 * @author nirmal
 */
public class UserView {

    private final int userId;
    private final String first_name;
    private final String last_name;
    private final String email;
    private final short status;
    private final Date dob;
    private final String gender;
    private final String profile;
    public String getCountry() {
		return country;
	}

	private final String country;
    
    @Json.DateTimeFormat
    private final Date createDate;
    @Json.DateTimeFormat
    private final Date updateDate;

    public UserView(User user) {
        this.userId = user.getUserId();
        this.first_name = user.getFirst_name();
        this.last_name = user.getLast_name();
        this.email = user.getEmail();
        this.status = user.getStatus();
        this.dob = user.getDob();
        this.gender = user.getGender();
        this.profile = user.getProfile();
        this.createDate = user.getCreateDate();
        this.updateDate = user.getUpdateDate();
        this.country=user.getCountry().getCountryName();
    }

	public int getUserId() {
		return userId;
	}

	public String getFirst_name() {
		return first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public String getEmail() {
		return email;
	}

	public short getStatus() {
		return status;
	}

	public Date getDob() {
		return dob;
	}

	public String getGender() {
		return gender;
	}


	public String getProfile() {
		return profile;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}


}
