/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementUser.controller;

import java.security.Principal;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovaturelabs.training.surveymanagementUser.entity.Question;
import com.innovaturelabs.training.surveymanagementUser.entity.Survey;
import com.innovaturelabs.training.surveymanagementUser.entity.User;
import com.innovaturelabs.training.surveymanagementUser.form.AnswerForm;
import com.innovaturelabs.training.surveymanagementUser.form.ChangePassword;
import com.innovaturelabs.training.surveymanagementUser.form.UserForm;
import com.innovaturelabs.training.surveymanagementUser.service.UserService;
import com.innovaturelabs.training.surveymanagementUser.view.AnswerView;
import com.innovaturelabs.training.surveymanagementUser.view.UserView;

/**
 *
 * @author nirmal
 */
@RestController
@RequestMapping("/users")
public class UsersController {

    @Autowired
    private UserService userService;
    
  

    @PostMapping
    public UserView add(@Valid @RequestBody UserForm form) {
        return userService.add(form);
    }

    @GetMapping("/list")
    public Collection<User> list() {
        return userService.list();
    }
    
    @GetMapping("/{userId}")
    public UserView get(@PathVariable("userId") Integer userId) {
    	return userService.get(userId);
    }
    
    @GetMapping("/survey")
    public Collection<Survey> lists(){
    	return userService.lists();
    }
    
    @GetMapping("/ques/{surveyId}")
	public Collection<Question> attendSurvey(Principal p,@PathVariable("surveyId") Integer surveyId){
		return userService.attendSurvey(surveyId);
	}
    
    @PostMapping("/{surveyId}/{questionId}")
    public AnswerView add(
            @Valid @RequestBody AnswerForm form,
            @PathVariable("surveyId")Integer surveyId,
            @PathVariable("questionId")Integer questionId){
        return userService.add(surveyId,questionId,form);
    }
    
    @PutMapping("/changePass")
    public UserView updatePassword(@Valid @RequestBody ChangePassword form) {
    	return userService.updatePassword(form);
    }
}
