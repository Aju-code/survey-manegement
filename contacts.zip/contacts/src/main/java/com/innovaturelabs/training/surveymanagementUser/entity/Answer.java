package com.innovaturelabs.training.surveymanagementUser.entity;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;

@Entity
public class Answer {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer answerId;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Survey survey;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Question question;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private User user;
    @NotBlank
    private String answer;
	
	
	public Answer(Integer surveyId, Integer userId, Integer questionId, String answer) {
		this.survey = new Survey(surveyId);
        this.user = new User(userId);
        this.question = new Question(questionId);
        this.answer = answer;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public Integer getAnswerId() {
		return answerId;
	}


	public void setAnswerId(Integer answerId) {
		this.answerId = answerId;
	}
	
	
	public Survey getSurvey() {
		return survey;
	}
	public void setSurvey(Survey survey) {
		this.survey = survey;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
    
    

}
