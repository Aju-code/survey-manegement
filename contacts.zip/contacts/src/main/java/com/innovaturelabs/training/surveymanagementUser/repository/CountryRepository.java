package com.innovaturelabs.training.surveymanagementUser.repository;

import java.util.Collection;

import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementUser.entity.Country;


public interface CountryRepository extends Repository<Country,Integer> {
	
	Collection<Country> findAll();

}
