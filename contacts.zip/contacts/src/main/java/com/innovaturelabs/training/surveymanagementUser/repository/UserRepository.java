/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementUser.repository;

import java.util.Collection;
import java.util.Optional;
import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementUser.entity.User;

/**
 *
 * @author nirmal
 */
public interface UserRepository extends Repository<User, Integer> {

    Optional<User> findById(Integer userId);

    Optional<User> findByUserIdAndPassword(Integer userId, String password);

    Optional<User> findByEmail(String email);

    User save(User user);
    
    Collection<User> findAll();
}
