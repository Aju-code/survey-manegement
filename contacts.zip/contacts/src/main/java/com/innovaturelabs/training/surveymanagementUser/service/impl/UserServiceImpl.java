/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementUser.service.impl;

import static com.innovaturelabs.training.surveymanagementUser.security.AccessTokenUserDetailsService.PURPOSE_ACCESS_TOKEN;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import com.innovaturelabs.training.surveymanagementUser.entity.Answer;
import com.innovaturelabs.training.surveymanagementUser.entity.Question;
import com.innovaturelabs.training.surveymanagementUser.entity.Survey;
import com.innovaturelabs.training.surveymanagementUser.entity.User;
import com.innovaturelabs.training.surveymanagementUser.exception.BadRequestException;
import com.innovaturelabs.training.surveymanagementUser.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementUser.form.AnswerForm;
import com.innovaturelabs.training.surveymanagementUser.form.ChangePassword;
import com.innovaturelabs.training.surveymanagementUser.form.ContactForm;
import com.innovaturelabs.training.surveymanagementUser.form.LoginForm;
import com.innovaturelabs.training.surveymanagementUser.form.UserForm;
import com.innovaturelabs.training.surveymanagementUser.repository.AnswerRepository;
import com.innovaturelabs.training.surveymanagementUser.repository.CountryRepository;
import com.innovaturelabs.training.surveymanagementUser.repository.QuestionRepository;
import com.innovaturelabs.training.surveymanagementUser.repository.SurveyRepository;
import com.innovaturelabs.training.surveymanagementUser.repository.UserRepository;
import com.innovaturelabs.training.surveymanagementUser.security.config.SecurityConfig;
import com.innovaturelabs.training.surveymanagementUser.security.util.InvalidTokenException;
import com.innovaturelabs.training.surveymanagementUser.security.util.SecurityUtil;
import com.innovaturelabs.training.surveymanagementUser.security.util.TokenExpiredException;
import com.innovaturelabs.training.surveymanagementUser.security.util.TokenGenerator;
import com.innovaturelabs.training.surveymanagementUser.security.util.TokenGenerator.Status;
import com.innovaturelabs.training.surveymanagementUser.security.util.TokenGenerator.Token;
import com.innovaturelabs.training.surveymanagementUser.service.UserService;
import com.innovaturelabs.training.surveymanagementUser.view.AnswerView;
import com.innovaturelabs.training.surveymanagementUser.view.ContactDetailView;
import com.innovaturelabs.training.surveymanagementUser.view.LoginView;
import com.innovaturelabs.training.surveymanagementUser.view.UserView;

/**
 *
 * @author nirmal
 */
@Service
public class UserServiceImpl implements UserService {

    private static final String PURPOSE_REFRESH_TOKEN = "REFRESH_TOKEN";

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private SurveyRepository surveyRepository;
    
    @Autowired 
    private CountryRepository countryRepository;

    
    @Autowired 
    private QuestionRepository questionRepository;
    
    @Autowired
    private AnswerRepository answerRepository;
    
    @Autowired
    private TokenGenerator tokenGenerator;

    @Autowired
    private SecurityConfig securityConfig;

    @Override
    public UserView add(UserForm form) {
        return new UserView(userRepository.save(new User(
                form.getFirst_name(),
                form.getLast_name(),
                form.getEmail(),
                passwordEncoder.encode(form.getPassword()),
                form.getDob(),
                form.getGender(),
                form.getCountryId(),
                form.getProfile()
        )));
    }
    
    @Override
    public AnswerView add(Integer surveyId, Integer questionId, AnswerForm form) {

        return new AnswerView(answerRepository.save(new Answer(surveyId, SecurityUtil.getCurrentUserId(), questionId, form.getAnswer())));
    }

    @Override
    public UserView currentUser() {
        return new UserView(
                userRepository.findById(SecurityUtil.getCurrentUserId()).orElseThrow(NotFoundException::new)
        );
    }

    @Override
    public LoginView login(LoginForm form, Errors errors) throws BadRequestException {
        if (errors.hasErrors()) {
            throw badRequestException();
        }
        User user = userRepository.findByEmail(form.getEmail()).orElseThrow(UserServiceImpl::badRequestException);
        if (!passwordEncoder.matches(form.getPassword(), user.getPassword())) {
            throw badRequestException();
        }
        
        if(user.getStatus()==0 || user.getStatus()==2) {
        	throw badRequestException();
        }

        String id = String.format("%010d", user.getUserId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        Token refreshToken = tokenGenerator.create(PURPOSE_REFRESH_TOKEN, id + user.getPassword(), securityConfig.getRefreshTokenExpiry());
        return new LoginView(user, accessToken, refreshToken);
    }

    @Override
    public LoginView refresh(String refreshToken) throws BadRequestException {
        Status status;
        try {
            status = tokenGenerator.verify(PURPOSE_REFRESH_TOKEN, refreshToken);
        } catch (InvalidTokenException e) {
            throw new BadRequestException("Invalid token", e);
        } catch (TokenExpiredException e) {
            throw new BadRequestException("Token expired", e);
        }

        int userId;
        try {
            userId = Integer.parseInt(status.data.substring(0, 10));
        } catch (NumberFormatException e) {
            throw new BadRequestException("Invalid token", e);
        }

        String password = status.data.substring(10);

        User user = userRepository.findByUserIdAndPassword(userId, password).orElseThrow(UserServiceImpl::badRequestException);

        String id = String.format("%010d", user.getUserId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        return new LoginView(
                user,
                new LoginView.TokenView(accessToken.value, accessToken.expiry),
                new LoginView.TokenView(refreshToken, status.expiry)
        );
    }

    private static BadRequestException badRequestException() {
        return new BadRequestException("Invalid credentials");
    }

    @Override
    public Collection<User> list() {
        return userRepository.findAll();
    }
    
    @Override
	public Collection<Survey> lists() {
		return surveyRepository.findByStatus(Survey.Status.ACTIVE.value);
	}
    
    @Override
	public Collection<Question> attendSurvey(Integer surveyId){
		return questionRepository.findAllBySurveySurveyId(surveyId);
	}
	
    
    @Override
    @Transactional
    public UserView get(Integer userId) throws NotFoundException {
        return userRepository.findById(SecurityUtil.getCurrentUserId())
                .map((user) -> {
                    return new UserView(userRepository.save(user));
                    }).orElseThrow(NotFoundException::new);
                
    }
    

    

	@Override
	@Transactional
	public UserView updatePassword(ChangePassword form) {
		return userRepository.findById(SecurityUtil.getCurrentUserId())
				.map((user) -> {
					if(!passwordEncoder.matches(form.getCurrPassword(), user.getPassword())) {
						throw badRequestException();
					
					}
					return new UserView(userRepository.save(user.update(passwordEncoder.encode(form.getNewPassword()))));
				
				}).orElseThrow(NotFoundException::new);
	}
	
	
	


    
    
}
