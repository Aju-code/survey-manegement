package com.innovaturelabs.training.surveymanagementUser.form;

import javax.validation.constraints.NotBlank;

import com.innovaturelabs.training.surveymanagementUser.form.validaton.Password;

public class ChangePassword {
	
	@NotBlank
	@Password
	private String currPassword;
	
	@NotBlank
	@Password
	private String newPassword;

	public String getCurrPassword() {
		return currPassword;
	}

	public void setCurrPassword(String currPassword) {
		this.currPassword = currPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	
	
	
	

}
