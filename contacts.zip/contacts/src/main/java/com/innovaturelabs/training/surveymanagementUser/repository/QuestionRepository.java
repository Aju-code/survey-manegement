package com.innovaturelabs.training.surveymanagementUser.repository;

import java.util.Collection;

import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementUser.entity.Question;

public interface QuestionRepository extends Repository<Question,Integer>{

	Collection<Question> findAllBySurveySurveyId(Integer surveyId);
	
}
